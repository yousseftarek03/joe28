package model.characters;

import com.sun.javafx.scene.paint.GradientUtils.Point;

public class Medic extends Hero{

	public Medic(String name, int maxHp, int attackDmg, int maxActions) {
         super(name,maxHp,attackDmg,maxActions);
	}

}
