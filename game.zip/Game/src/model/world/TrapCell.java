package model.world;

public class TrapCell extends Cell {
	private int trapDamage;	
	
	public TrapCell() {
		int r = (int) ((Math.random() * 3) + 1);
		trapDamage = r * 10;
	}
	
	
	
	public int getTrapDamage() {
		return trapDamage;
	}

}
