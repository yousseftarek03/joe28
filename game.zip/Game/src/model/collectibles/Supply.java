package model.collectibles;

public class Supply implements Collectible {


}
