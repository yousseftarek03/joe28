package model.collectibles;

public class Vaccine implements Collectible{

}
