package engine;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

import model.characters.Explorer;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.world.Cell;

public class Game {
	
	public static ArrayList<Hero> availableHeroes;
	public static ArrayList<Hero> heroes;
	public static ArrayList<Zombie> zombies;
	public static Cell [][] map;
	
	public static void loadHeroes(String filePath) throws Exception{
		 BufferedReader reader = new BufferedReader(new FileReader(filePath));
		    String line="";
		    while ((line = reader.readLine()) != null) {
		        String[] values = line.split(",");
		        String name = values[0];
		        String type = values[1];
		        int maxHp = Integer.parseInt(values[2]);
		        int attackDmg = Integer.parseInt(values[4]);
		        int maxActions = Integer.parseInt(values[3]);
		        switch(type){
		        case "FIGH":
		        	availableHeroes.add(new Fighter(name,maxHp,attackDmg,maxActions));
		        	break;
		        case "EXP":
		        	availableHeroes.add(new Explorer(name,maxHp,attackDmg,maxActions));
		        	break;
		        case "MED":
		        	availableHeroes.add(new Medic(name,maxHp,attackDmg,maxActions));
		        	break;
		        }
		      
		     }
		    reader.close();	 
		 }
	}

	
	
	

